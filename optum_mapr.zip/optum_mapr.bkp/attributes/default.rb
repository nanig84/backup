# host adding new #

case node['hostname']
when 'apsrs6775'
  default['apsrs6775']['zone'] = 'unh'
  default['apsrs6775']['env'] = 'dev'
when 'apsrs6756'
  default['apsrs6756']['zone'] = 'unh'
  default['apsrs6756']['env'] = 'test'
when 'apsrd9425'
  default['apsrd9425']['zone'] = 'unh'
  default['apsrd9425']['env'] = 'dev'
when 'apsrd9601'
  default['apsrd9601']['zone'] = 'unh'
  default['apsrd9601']['env'] = 'dev'
when 'apsrp04093'
  default['apsrp04093']['zone'] = 'unh'
  default['apsrp04093']['env'] = 'prod'
when 'apsrs7131'
  default['apsrs7131']['zone'] = 'unh'
  default['apsrs7131']['env'] = 'test'
else
  host = node['hostname']
  default[host]['zone'] = 'unh'
  default[host]['env'] = 'test'
end

default['package_names'] = { 'snow' => '', 'aplpack' => '1.3.0' }
# case node.chef_environment
# when 'prod'
#   default['ssl_trust_store'] = ""
#   default['mapr-clusters.conf'] = ""
# when 'dev'
#   default['ssl_trust_store'] = ""
#   default['clusters_conf'] = ""
# when 'staging'
#   default['ssl_trust_store'] = ""
#   default['clusters_conf'] = ""
# when 'test'
#   default['ssl_trust_store'] = ""
#   default['clusters_conf'] = ""
# else
#   default['ssl_trust_store'] = ""
#   default['clusters_conf'] = ""
# end

default['repo_server'] = 'http://apsrs6756.uhc.com/'
# default['nodejs_url'] = 'https://rpm.nodesource.com/setup_6.x'
default['pkg_name'] = %w( pcre pcre-devel xz xz-devel bzip2-devel libicu-devel
                          gcc-gfortran.x86_64
                          zlib.x86_64
                          unixODBC-devel
                          unixODBC
                          libtool
                          readline-devel
                          python-devel.x86_64
                          libxml2-devel
                          openssl-devel.x86_64
                          libcurl-devel
                          gcc-c++
                          make
                          gcc
                          firefox
                          git
                          zlib.x86_64
                          zlib-devel.x86_64 nfs-utils
                          java-1.8.0-openjdk-devel
                          nss
                          unzip)
