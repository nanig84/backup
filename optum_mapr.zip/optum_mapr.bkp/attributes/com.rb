default['com']['dev']['mapr'] =  ['mapr-client.x86_64', 'mapr-hbase.noarch']
default['com']['stg']['mapr'] =  ['mapr-spark.noarch']
default['com']['Prodzone']['mapr'] = ['mapr-spark.noarch']
