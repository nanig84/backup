cookbook_file '/opt/r-install-dir/r_packages_300.json' do
  source 'r_packages_300.json'
end

cookbook_file '/opt/r_packages.json' do
  source 'r_packages.json'
end

cron 'r-packages-install' do
  minute '0'
  hour '*/23'
  mailto 'goutham.guduguntla@optum.com'
  command 'chef-client -o recipe[optum_mapr::r-packages-install] -j /opt/r_packages_300.json'
  action :create
end
