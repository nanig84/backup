chef_gem 'rinruby' do # ~FC009
  compile_time false if respond_to?(:compile_time)
end

node['package_names'].keys.each do |pkg_name|
  package_install "install #{pkg_name}" do
    package pkg_name
    version node['package_names'][pkg_name] unless node['package_names'][pkg_name].empty?
    action :install
  end
end

ruby_block 'pkg status' do
  block do
    check_package_status
  end
end
