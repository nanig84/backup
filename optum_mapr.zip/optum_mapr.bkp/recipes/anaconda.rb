# remote_file "/app/#{node['pkg_anaconda']}" do
#   source "#{node['repo_server']}/softwares/#{node['pkg_anaconda']}"
#   action :create
# end
hname = node['hostname']
# hzone = node[hname.to_s]['zone']
# henv  = node[hname.to_s]['env']

remote_file "/app/packages/#{node.normal['pkg_anaconda']}" do
  source "#{node.default['repo_server']}/softwares/#{node.normal['pkg_anaconda']}"
  action :create
end

bash "#{node['pkg_anaconda']} installation" do
  user 'root'
  cwd '/app/packages'
  code <<-EOH
   /bin/sh #{node['pkg_anaconda']} -b -f -p /app/anaconda3
  EOH
  not_if { File.exist?('/app/anaconda3') }
end

execute 'curl --silent --location https://rpm.nodesource.com/setup_6.x | bash -' do
  not_if { File.exist?('/etc/yum.repos.d/nodesource-el.repo') }
end

yum_package 'nodejs' do
  ignore_failure true
end

execute 'npm install -g configurable-http-proxy' do
  not_if { ::File.exist? '/usr/lib/node_modules/configurable-http-proxy/bin/configurable-http-proxy' }
end

bash node['pkg_anaconda'].to_s do
  user 'root'
  cwd '/app/anaconda3'
  code <<-EOH
  /app/anaconda3/bin/conda install -c conda-forge jupyterhub=0.7.2
  EOH
  not_if { ::File.exist?('/app/anaconda3/bin/conda') && Mixlib::ShellOut.new('/app/anaconda3/bin/conda -V').run_command.stdout.chomp =~ /conda 4.3.../ }
end

bash 'notebook installation' do
  user 'root'
  cwd '/app/anaconda3'
  code <<-EOH
  /app/anaconda3/bin/conda install notebook
  EOH
  not_if { ::File.exist? '/app/anaconda3/envs/python275' }
end

bash 'python 3.5.2 installation' do
  user 'root'
  cwd '/app/anaconda3'
  code <<-EOH
  /app/anaconda3/bin/conda create -n python352 python=3.5.2 ipykernel
  source /app/anaconda3/bin/activate python352
  /app/anaconda3/envs/python352/bin/python -m ipykernel install --name python352 --display-name "Python (3.5.2)"
  source /app/anaconda3/bin/deactivate python352
  EOH
  not_if { Mixlib::ShellOut.new('conda env list | grep python352').run_command.stdout.chomp == 'python352                /app/anaconda3/envs/python352' }
end

bash 'python 2.7.5 installation' do
  user 'root'
  cwd '/app/anaconda3'
  code <<-EOH
  /app/anaconda3/bin/conda create -n python275 python=2.7.5 ipykernel
  source /app/anaconda3/bin/activate python275
  /app/anaconda3/envs/python275/bin/python -m ipykernel install --name python275 --display-name "Python (2.7.5)"
  source /app/anaconda3/bin/deactivate python275
  EOH
  not_if { Mixlib::ShellOut.new('conda env list | grep python275').run_command.stdout.chomp == 'python275                /app/anaconda3/envs/python275' }
end

# bash node['pkg_anaconda'].to_s do
#   user 'root'
#   cwd '/app/anaconda3'
#   code <<-EOH
#   /app/anaconda3/bin/conda install -c conda-forge jupyterhub=0.7.2
#   /app/anaconda3/bin/conda install notebook
#   /app/anaconda3/bin/conda create -n python352 python=3.5.2 ipykernel
#   source /app/anaconda3/bin/activate python352
#   /app/anaconda3/envs/python352/bin/python -m ipykernel install --name python352 --display-name "Python (3.5.2)"
#   source /app/anaconda3/bin/deactivate python352
#   /app/anaconda3/bin/conda create -n python275 python=2.7.5 ipykernel
#   source /app/anaconda3/bin/activate python275
#   /app/anaconda3/envs/python275/bin/python -m ipykernel install --name python275 --display-name "Python (2.7.5)"
#   source /app/anaconda3/bin/deactivate python275
#   EOH
# end

# mkdir /app/anaconda3/srv
directory '/app/anaconda3/srv' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

# %w(jupyterhub.key jupyterhub.crt).each do |f1|
#   cookbook_file "/app/anaconda3/srv/#{f1}" do
#     source f1.to_s
#     mode '0755'
#     action :create
#   end
# end

%w(jupyterhub_config.py cull_idle_servers.py startjupyterhub.sh).each do |f1|
  cookbook_file "/app/anaconda3/bin/#{f1}" do
    source f1.to_s
    mode '0755'
    action :create
  end
end
if node['platform_version'] >= '7'
  cookbook_file '/etc/systemd/system/jupyterhub.service' do
    source 'jupyterhub.service'
    mode '0755'
    action :create
  end
else
  cookbook_file '/etc/init.d/jupyterhub' do
    source 'jupyterhubprod'
    mode '0755'
    action :create
  end
end

service 'jupyterhub' do
  action %i(enable start)
  notifies :run, 'execute[chkconfig level]', :immediately
end

execute 'chkconfig level' do
  command 'sudo chkconfig --level 2345 jupyterhub on'
  action :nothing
  only_if { node['platform_version'] < '7' }
end
remote_file '/app/packages/pycharm-community-2017.2.3.tar.gz' do
  source "#{node['repo_server']}/softwares/pycharm-community-2017.2.3.tar.gz"
  # source "#{node['repo_server']}/softwares/nz/nz.tar"
  action :create
end

bash 'extract_module pycharm' do
  cwd '/app'
  code <<-EOH
    mkdir -p  /app/pycharm/
    tar -xzf /app/packages/pycharm-community-2017.2.3.tar.gz -C /app/pycharm/
    EOH
  not_if { ::File.exist?('/app/pycharm/pycharm-community-2017.2.3') }
end

%w(pyspark2 pyspark3 ir33).each do |dir_name|
  directory "/usr/local/share/jupyter/kernels/#{dir_name}" do
    action :create
    recursive true
  end
end

cookbook_file '/usr/local/share/jupyter/kernels/pyspark2/kernel.json' do
  source "kernel.json.py275.#{node[hname.to_s]['env']}"
end

cookbook_file '/usr/local/share/jupyter/kernels/pyspark3/kernel.json' do
  source "kernel.json.py352.#{node[hname.to_s]['env']}"
end

cookbook_file '/usr/local/share/jupyter/kernels/ir33/kernel.json' do
  source 'kernel.json.ir33'
end

directory '/opt/mapr/tools/python' do
  action :create
  recursive true
end

# ln -s /app/anaconda3/envs/python275  /opt/mapr/tools/python/anaconda2
link '/opt/mapr/tools/python/anaconda2' do
  to '/app/anaconda3/envs/python275'
end

# ln -s /app/anaconda3/envs/python352  /opt/mapr/tools/python/anaconda3
link '/opt/mapr/tools/python/anaconda3' do
  to '/app/anaconda3/envs/python352'
end
