# mkdir /app/zeppelin
directory '/app/zeppelin' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/app/packages/zeppelin-0.7.2-bin-all.tgz' do
  source "#{node['repo_server']}/softwares/zeppelin-0.7.2-bin-all.tgz"
  action :create
end

bash 'extract_module' do
  cwd '/app/packages'
  code <<-EOH
    tar -xzvf /app/packages/zeppelin-0.7.2-bin-all.tgz -C /app/zeppelin
    mv /app/zeppelin/zeppelin-0.7.2-bin-all /app/zeppelin/zeppelin-0.7.2
    chown -R root:root /app/zeppelin/zeppelin-0.7.2
    EOH
  not_if { ::File.exist?('/app/zeppelin/zeppelin-0.7.2') }
end
# execute "tar -xzvf /packages/zeppelin-0.7.2-bin-all.tgz  -C /app/zeppelin" do
#   cwd '/app/zeppelin/'
#   not_if { File.exist?("/app/zeppelin/zeppelin-0.7.2") }
# end
#
# execute "mv /app/zeppelin/zeppelin-0.7.2-bin-all /app/zeppelin/zeppelin-0.7.2" do
#   cwd '/app/zeppelin/'
#   not_if { File.exist?("/app/zeppelin/zeppelin-0.7.2") }
#  end

%w(shiro.ini zeppelin-site.xml).each do |z1|
  cookbook_file "/app/zeppelin/zeppelin-0.7.2/conf/#{z1}" do
    source z1.to_s
    action :create
  end
end

if node['platform_version'] >= '7'
  cookbook_file '/etc/systemd/system/zeppelin.service' do
    source 'zeppelin.service'
    mode '0755'
    action :create
  end
else
  cookbook_file '/etc/init.d/zeppelin' do
    source 'zeppelinprod'
    mode '0755'
    action :create
  end
end

service 'zeppelin' do
  action %i(enable start)
end
