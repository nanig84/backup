#
# Cookbook Name:: optum_mapr/
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
# hname = "#{node['hostname']}"
# hzone = "#{node[hname]}#{node['zone']}"
# henv  = "#{node[hname]}#{node['env']}"
# #hpkgmapr = node[hzone][henv]['mapr']
hname = node['hostname']
hzone = node[hname.to_s]['zone']
henv  = node[hname.to_s]['env']
# hpkgmapr = node[hzone.to_s][henv.to_s]['mapr']

cookbook_file '/etc/profile.d/hadoop_env.sh' do
  source 'hadoop.env'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

# ["#{node[hzone]}#{node[henv]}#{node['mapr']}"].each do |p|

node[hzone.to_s][henv.to_s]['mapr'].each do |p|
  yum_package p do
    # yum_package "#{hpkgmapr}"
    # yum_package ['mapr-client.x86_64', 'mapr-hbase.noarch', 'mapr-hive.noarch', 'mapr-hivemetastore.noarch', 'mapr-hiveserver2.noarch', 'mapr-spark.noarch'] do
    ignore_failure true
  end
end

link '/opt/mapr/hbase/hbase' do
  to '/opt/mapr/hbase/hbase-1.1.8'
end

link '/opt/mapr/hadoop/hadoop' do
  to '/opt/mapr/hadoop/hadoop-2.7.0'
end

link '/opt/mapr/hive/hive' do
  to '/opt/mapr/hive/hive-2.1'
end

link '/opt/mapr/spark/spark' do
  to '/opt/mapr/spark/spark-2.1.0'
end

directory '/opt/mapr/tmp' do
  owner 'root'
  group 'root'
  mode '0755'
  recursive true
  action :create
end

directory '/opt/mapr/tmp/aaldbpdv' do
  owner 'root'
  group 'root'
  mode '0777'
  action :create
end

directory '/opt/mapr/java' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/opt/mapr/java/jdk-8u101-linux-x64.tar.gz' do
  source "#{node['repo_server']}/softwares/jdk-8u101-linux-x64.tar.gz"
  action :create
end

bash 'extract_module' do
  cwd '/opt/mapr/java'
  code <<-EOH
    tar -xzf jdk-8u101-linux-x64.tar.gz
    EOH
  not_if { ::File.exist?('/opt/mapr/java/jdk1.8.0_101') }
end

remote_file '/opt/mapr/conf/ssl_truststore' do
  source "#{node['repo_server']}/mapr/#{node[hzone.to_s][henv.to_s]['ssl_truststore']}"
  action :create
end

link '/opt/mapr/conf/ssl-client.xml' do
  to '/opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop/ssl-client.xml'
end

link '/opt/mapr/conf/ssl-server.xml' do
  to '/opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop/ssl-server.xml'
end

cookbook_file '/opt/mapr/conf/dbclient.conf' do
  source 'dbclient.conf'
  mode '0755'
  action :create
end

link '/opt/mapr/sqoop/sqoop' do
  to '/opt/mapr/sqoop/sqoop-1.4.6'
end

remote_file '/opt/mapr/spark/spark-2.1.0/jars/hadoop-yarn-server-web-proxy-2.6.0.jar' do
  source "#{node['repo_server']}/softwares/hadoop-yarn-server-web-proxy-2.6.0.jar"
  action :create
end

remote_file '/opt/mapr/spark/spark-2.1.0/examples/jars/spark-examples-1.6.1-mapr-1605-hadoop2.7.0-mapr-1602.jar' do
  source "#{node['repo_server']}/softwares/mapr/spark-examples-1.6.1-mapr-1605-hadoop2.7.0-mapr-1602.jar"
  action :create
end

remote_file '/opt/mapr/spark/spark-2.1.0/examples/jars/spark-examples_2.11-2.1.0-mapr-1703.jar' do
  source "#{node['repo_server']}/softwares/mapr/spark-examples_2.11-2.1.0-mapr-1703.jar"
  action :create
end

cookbook_file '/opt/mapr/sqoop/sqoop/conf/sqoop-site.xml' do
  source 'sqoop-site.xml'
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/conf/mapr-clusters.conf' do
  source "mapr-clusters-#{node[hname.to_s]['env']}.conf"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/hadoop/hadoop/etc/hadoop/mapred-site.xml' do
  source "mapred-site-#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/hadoop/hadoop/etc/hadoop/yarn-site.xml' do
  source "yarn-site-#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/spark/spark/conf/hive-site.xml' do
  source "hive-site-#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/hbase/hbase/hbase-site.xml' do
  source "hbase-site-#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/hive/hive/conf/hive-site.xml' do
  source "hive-sitexml-#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/spark/spark/conf/spark-defaults.conf' do
  source "spark-defaults-#{node[hname.to_s]['env']}.conf"
  mode '0755'
  action :create
end

bash 'beforeTest' do
  code <<-EOF
  echo "spark-defaults-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.conf"
  EOF
end

# temporay - DS
# cookbook_file '/opt/mapr/spark/spark/conf/spark-defaults.conf2' do
#   source "spark-defaults-#{node[hzone]}#{node[henv]}.conf"
#   mode '0755'
#   action :create
# end
##

cookbook_file '/etc/hosts' do
  source "host-#{node[hname.to_s]['env']}"
  mode '0755'
  action :create
end

# MAPR TICKET PAM
remote_file '/opt/mapr/lib/libmapr_pam.so' do
  source "#{node['repo_server']}/softwares/mapr/libmapr_pam.so"
  action :create
end

directory '/opt/mapr/tickets' do
  owner 'root'
  group 'root'
  mode '0777'
  action :create
end

cookbook_file '/etc/pam.d/system-auth-local' do
  source 'PAM-system-auth-local'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

cookbook_file '/etc/pam.d/password-auth-ac' do
  source 'PAM-password-auth-ac'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end
