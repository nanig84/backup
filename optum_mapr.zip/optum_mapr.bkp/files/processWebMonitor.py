#!/usr/bin/env python
###################################
## Description
###################################
##
## Author:      David Shakespeare
## Version: 0.1
## Usage:       Capture Server usage and record in database
##                                      CPU, Memory and User Count
##
## History:
##
##################################o
# configparser
###################################
## Import libs
###################################

from __future__ import print_function
from datetime import datetime
from collections import OrderedDict
import configparser
import ast
import psutil
import json
import multiprocessing
import threading
import platform
import sys
import smtplib
import ast
from pprint import pprint
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from mako.template import Template

try:    #In python 3 urllib2 was merged into urllib
    import urllib.request as urllib2
except ImportError:
    import urllib2

from decimal import Decimal
import time


###################################
## Variables
###################################
listCount=1
AlertStatus=False
ThresholdDelayTime=0
ThresholdDelayTimeLong=1
ThresTrys=0
BODYCPU=0
BODYMEM=0

HttpGetError=0
HttpPutError=0

UserCount_List = []
CPU_List = []
memused_list = []
memFree_list = []

threads = []

ThresMonitor = {}
ThresMemMon = {}

ServProcDict = {}
ServProcList = []

###################################
## VConfig ariables - TO BE EXPORTED TO CONFIG FILE
###################################

config = configparser.ConfigParser()
config.read("default.conf")

SleepTime=config['MAIN']['SleepTime']
FromEmail=config['MAIL']['FromEmail']
ToEmail=config['MAIL']['ToEmail']
MailServer=config['MAIL']['MailServer']
Threshold_CPU=ast.literal_eval(config.get('THRESHOLDS','Threshold_CPU'))
Threshold_MEM=ast.literal_eval(config.get('THRESHOLDS','Threshold_MEM'))
ThresholdWaitTime=config['THRESHOLDS']['ThresholdWaitTime']
ThresholdWaitTimeLong=config['THRESHOLDS']['ThresholdWaitTimeLong']
ThresholdRetrys=config['THRESHOLDS']['ThresholdRetrys']
PrintToScreen=ast.literal_eval(config['DEBUG']['PrintToScreen'])
PrintToScreenDebug=ast.literal_eval(config['DEBUG']['PrintToScreenDebug'])
SendWebStats=ast.literal_eval(config['WEB']['SendWebStats'])
portalURL=ast.literal_eval(config['WEB']['portalURL'])
excludedUsers=ast.literal_eval(config.get('MAIN','excludedUsers'))



#Populate the threholds into dictionary
for x in Threshold_CPU:
  ThresMonitor[x] = 0

for i in Threshold_MEM:
  ThresMemMon[i] = 0


###################################
## Functions
###################################

#Runs on first execution of script
def run():
    global aggregateTime
    global hostname
    time.sleep(0) # sleep at bring to wait for server to startup

    print ("Started")
    if len(sys.argv)<2:
      aggregateTime = 10
      print ("No time given, defaulting to 10 seconds")
      print ('No Hosts Names Given')
    else:
      aggregateTime = sys.argv[1]
      hostname = sys.argv[2]

    if PrintToScreenDebug: print("Input Parmater: ",aggregateTime )


#runs prediocal and collects server stats
def ServerStat():
    global ppidlist

    #CPU Usage
    cpuUsage = psutil.cpu_percent()
    mem =  psutil.virtual_memory()
    memUsed = round((mem.used) / (1024.0 ** 2))
    memFree = round((mem.available)  / (1024.0 ** 2))

    now = datetime.now()
    startDay = now.replace(hour=0, minute=0, second=0, microsecond=0)

    # get all the unique users that are connected. not all users will have termial connections
    ProcessDetails('users')
    s = set()
    for dic in ppidlist:
      if dic['username'] not in excludedUsers:
        if str(startDay) <= dic['time']:
          s.add(dic['username'])
    UserCount = len(s)
    s =set()

    return [UserCount, cpuUsage, memUsed, memFree]

#once stats have been collected they are sent the webserver it enabled and alerts
def CalcServerStat():
    global aggregateTime
    global listCount
    global sleepTime
    global currentTime
    global AlertStatus
    global BODYCPU
    global BODYMEM
    global hostname

    ###################################
    # Server Spec
    ###################################
    mem =  psutil.virtual_memory()
    maxMem = round((mem.total) / (1024.0 ** 3))
    cpuTot = multiprocessing.cpu_count()

    ###################################
    #Server Stats
    ###################################

    #run function to get server stats
    stats = ServerStat()
    #time to sleep between stat parse
    time.sleep(int(SleepTime))

    #populate the lists so th eaverage can be taken over period of time
    if listCount <= int(aggregateTime):
        UserCount_List=stats[0]
        CPU_List.append(stats[1])
        memused_list.append(stats[2])
        memFree_list.append(stats[3])
        listCount=listCount+1

    #Calc averages
    CPUAvg = round(float(sum(CPU_List) / len(CPU_List)))
    memUsedAvg = round(float(sum(memused_list) / len(memused_list)))
    memFreeAvg = round(float(sum(memFree_list) / len(memFree_list)))

    #Check against thersholds and alert if required
    for x in Threshold_CPU:
       # print(x)
        if CPUAvg >= x:
            AlertType='CPU'
            BODYCPU=CPUAvg
            ThresholdReached=x
            ThresholdTime = currentTime
            AlertStatus=True
            Alert(AlertType,ThresholdReached, ThresholdTime)
        else:
            AlertStatus=False
            clearAlertCheck()
    for x in Threshold_MEM:
        if memFreeAvg <= x:
            AlertType='MEM'
            BODYMEM=memFreeAvg
            ThresholdReached=x
            ThresholdTime = currentTime
            AlertStatus=True
            Alert(AlertType, ThresholdReached, ThresholdTime)
        else:
            AlertStatus=False
            clearAlertCheck()
    # get average usage over the time period of "aggregateTime"
    if listCount == int(aggregateTime):

        data = {
            'workstation': hostname,
            'totcpu': cpuTot,
            'maxmem': maxMem,
            'users': UserCount_List,
            'cpu': CPUAvg,
            'memused': memUsedAvg,
            'memfree': memFreeAvg
        }
        # If True send the stats to the web server
        if SendWebStats:
         publishToServer(data)        #publish json data to web server

        #clear variables and start again
        listCount=0
        CPU_List[:]=[]
        memused_list[:]=[]
        memFree_list[:]=[]

#start alerting thread - subprocess
def Alert(AlertType, ThresholdReached, ThresholdTime):
      try:
        t = threading.Thread(target=AlertThread, args=(AlertType, ThresholdReached, ThresholdTime))
        threads.append(t)
        t.start()

      except:
        if PrintToScreenDebug: print ("Error: unable to start alert thread")

#alerting function, determines the alert and if and when to send
def AlertThread(AlertType, ThresholdReached, ThresholdTime):
    import time
    global currentTime
    global AlertStatus
    global ThresholdDelayTime
    global ThresholdDelayTimeLong
    global ThresTrys
    global EXTRABODY
    global hostname

    if PrintToScreenDebug: print('Alert Thersholds Reached',AlertType,str(ThresholdReached),AlertStatus)


    if AlertType == 'CPU':
        ProcessDetails('cpu')
        SUBJECT='DSW ALERT: Host %s has triggered a CPU Threshold at %s percent' % (str(hostname), str(ThresholdReached))
        BODY='ACTION REQUIRED! \nDSW Host: %s has triggered CPU Usage above %s percent at %s percent %s' % (str(hostname), str(ThresholdReached), str(BODYCPU), str(EXTRABODY))

        # if first alert is not true start here
        #
        if AlertStatus != True:
          AlertStatus=True                                                        # Set alert status to true
          ThresholdDelayTime = ThresholdTime + int(ThresholdWaitTime)             # set the next alert check time. current time + delay
          ThresholdDelayTimeLong = ThresholdTime + int(ThresholdWaitTimeLong)     # set next alert time for next check, this happens after x times
          ThresMonitor[ThresholdReached] = ThresholdDelayTime                     # update the dictory with the time for that threshold alert (85, time())
        else:
          if ThresTrys <= int(ThresholdRetrys):                                   # if the number of times is less then
            if currentTime > ThresholdDelayTime:       #possible bug ?            # again check current time has not get deplay time
              ThresTrys=ThresTrys+1
              for thres,val in  ThresMonitor.items():
                if val != 0:
                  if thres > ThresholdReached:                                    #check that the thres is greater then current threshold being fired
                    ThresMonitor[thres] = 0                                       #if it is reset and use the new threshold (if was 85 and now 90, use 90)
                    AlertStatus=False
                    break

              if ThresholdTime > ThresMonitor[ThresholdReached]:                    # if current time is greater then time in dictioary
                ThresholdDelayTime = ThresholdTime + int(ThresholdWaitTime)         ## set the next alert check time. current time + delay
                ThresholdDelayTimeLong = ThresholdTime + int(ThresholdWaitTimeLong) # set next alert time for next check, this happens after x times
                send_mail(SUBJECT, BODY)                                            #send alert
                AlertStatus=True                                                    #set alert to true
                ThresMonitor[ThresholdReached] = ThresholdDelayTime                 # rset time
          else:
            if currentTime > ThresholdDelayTimeLong:
              ThresTrys=0

    if AlertType == 'MEM':
        ProcessDetails('mem')
        SUBJECT='DSW ALERT: Host %s has triggered a Memory Threshold. Server has Memory LOW!' % (str(hostname))
        BODY='ACTION REQUIRED! \nDSW Host: %s has triggered Memory Usage below %s MB at %s MB %s ' % (str(hostname), str(ThresholdReached), str(BODYMEM), str(EXTRABODY))

        if AlertStatus != True:
          AlertStatus=True
          ThresholdDelayTime = ThresholdTime + int(ThresholdWaitTime)
          ThresholdDelayTimeLong = ThresholdTime + int(ThresholdWaitTimeLong)
          ThresMemMon[ThresholdReached] = ThresholdDelayTime
        else:
          if ThresTrys <= int(ThresholdRetrys):
            if currentTime > ThresholdDelayTime:
              ThresTrys=ThresTrys+1
              for thres,val in  ThresMemMon.items():
                if val != 0:
                  if thres > ThresholdReached:
                    ThresMemMon[thres] = 0
                    AlertStatus=False
                    break
              if ThresholdTime > ThresMemMon[ThresholdReached]:
                ThresholdDelayTime = ThresholdTime + int(ThresholdWaitTime)
                ThresholdDelayTimeLong = ThresholdTime + int(ThresholdWaitTimeLong)
                send_mail(SUBJECT, BODY)
                AlertStatus=True
                ThresMemMon[ThresholdReached] = ThresholdDelayTime

          else:
            # if after ThresholdRetrys (3) times delay sending out for ThresholdDelayTime2(30min)
            if currentTime > ThresholdDelayTimeLong:
              ThresTrys=0

#email function
def send_mail(SUBJECT, BODY):
    global EXTRABODY
    #Function for sending Emails
    msg = MIMEText(BODY,_subtype='html',_charset='windows-1255')
    msg['From'] = FromEmail
    msg['To'] = ToEmail
    msg['Subject'] = SUBJECT

    s = smtplib.SMTP(MailServer)
    s.sendmail(FromEmail,ToEmail, msg.as_string())
    s.quit()

#send stats to the web server
def publishToServer(data):
    global HttpGetError
    global HttpPutError
    global hostname
    # publish data to the web server
    if PrintToScreen: print(data)

    ###################################################
    ## Get api from webserver
    ###################################################
    try:
      response = urllib2.urlopen(portalURL)
    except urllib2.HTTPError, e:
      if PrintToScreen: print ('HTTP Error on Get = ' + str(e.code))
      HttpPutError=HttpPutError+1
      if HttpPutError >= 10:
        send_mail('DSW ALERT: Error getting API Info from Host %s '% (hostname), 'Error getting API Info from Host %s <br> No Server Stats can be sent until resolved! <br> %s %s' % (hostname, str(e.reason), str(e.code)))
        HttpPutError=0
      return
    except urllib2.URLError, e:
      if PrintToScreen: print ('URL Error on Get = ' + str(e.reason))
      HttpPutError=HttpPutError+1
      if HttpPutError >= 10:
              send_mail('DSW ALERT: Error getting API Info from Host %s '% (hostname), 'Error getting API Info from Host %s <br> No Server Stats can be sent until resolved! <br> %s %s' % (hostname, str(e.reason), str(e.code)))
              HttpPutError=0
      return
    resp_data = json.load(response)
    for key, val in resp_data.iteritems():
      if key == 'workstationPerformanceUrl':
        PortalPerfUrl=val

    #Reset if there is no errors
    HttpPutError=0

    ###################################################
    ## Push data to api on web server
    ###################################################

    req = urllib2.Request(PortalPerfUrl)
    req.add_header('Content-Type', 'application/json')
    try:
      response = urllib2.urlopen(req, json.dumps(data))
    except urllib2.HTTPError, e:
      if PrintToScreen: print ('HTTP Error on Push = ' + str(e.code))
      HttpGetError=HttpGetError+1
      if HttpGetError >= 10:
        send_mail('DSW ALERT: Error Pushing Server Stats from Portal API %s ' % (hostname) ,'Error Pushing Server Stats from Portal API %s   <br> %s %s' % (hostname, str(e.reason), str(e.code)))
        HttpGetError=0
      return
    except urllib2.URLError, e:
      if PrintToScreen: print ('URL Error on Push = ' + str(e.reason))
      HttpGetError=HttpGetError+1
      if HttpGetError >= 10:
              send_mail('DSW ALERT: Error Pushing Server Stats from Portal API %s ' % (hostname) ,'Error Pushing Server Stats from Portal API %s   <br> %s %s' % (hostname, str(e.reason), str(e.code)))
              HttpGetError=0
      return

    #Reset if there is no errors
    HttpGetError=0


#update time
def updateTime():
                global currentTime
                currentTime=time.time()

#clear alerts if time has proceed and checks
def clearAlertCheck():
    #of the current time is greater then the alertime, reset to 0
    #this is to prevent alerts threshold dropping for a second
    global currentTime
    for thres,alertTime in ThresMonitor.items():
      if alertTime != 0:
        if currentTime > alertTime:
           ThresMonitor[thres] = 0
           AlertStatus=False

    for t in threads:
     t.join()
     threads.remove(t)


def ProcessDetails(protype):
  global EXTRABODY
  global ppidlist

  for p in psutil.process_iter():
      try:
          if protype == 'cpu':
            with p.oneshot():
              p.cpu_percent(interval=0.1)

          with p.oneshot():
            ServProcDict={  'pid' : p.pid,
                            'ppid' : p.ppid(),
                            'username' : p.username(),
                            'command' : p.name(),
                            'cpu' : round(p.cpu_percent() / psutil.cpu_count()),
                            'cpunum' : p.cpu_num(),
                            'mem' : round(p.memory_percent()),
                            'time' : datetime.fromtimestamp(p.create_time()).strftime("%Y-%m-%d %H:%M:%S"),
                            'status' : p.status(),
                            'exe' : p.exe()
                         }
            ServProcList.append(ServProcDict)
            ServProcDict = {}
      except (psutil.NoSuchProcess, psutil.ZombieProcess):
          pass
  if protype == 'users':
    ppidlist = sorted(ServProcList, key=lambda k: k['username'], reverse=True)
    return
  else:
    newlist = sorted(ServProcList, key=lambda k: k[protype], reverse=True)[:15]#number of rows to display

  template = """
  <br>
  <br>
  <table style="width:100%" border=1>
        <tr align="left">
          <th>Pid</th>
          <th>Parent pid</th>
          <th>Username</th>
          <th>Command</th>
          <th>Cpu %</th>
          <th>CpuNum</th>
          <th>Memory %</th>
          <th>Time</th>
          <th>status</th>
          <th>Command Line</th>
        </tr>
  % for user in newlist:
        <tr>
          <td>${user['pid']}</td>
          <td>${user['ppid']}</td>
          <td>${user['username']}</td>
          <td>${user['command']}</td>
          <td>${user['cpu']}</td>
          <td>${user['cpunum']}</td>
          <td>${user['mem']}</td>
          <td>${user['time']}</td>
          <td>${user['status']}</td>
          <td>${user['exe']}</td>
        </tr>
  % endfor
  </table>
  <br>
  <p>
  <b>Note</b>: Memory Value is percentage of whole system memory, CPU percentage is of all system threads (12)
  </p>
  """

  EXTRABODY = Template(template).render(newlist=newlist)

###################################
## Main
###################################

#Run on first execution
#run()
def main():
    run()

if __name__ == "__main__":
    main()

#Main script loop
while True:
  try:
      #get update to date time
      updateTime()
      #get server stats
      CalcServerStat()

  except KeyboardInterrupt:
      print ('Quitting')
      break
