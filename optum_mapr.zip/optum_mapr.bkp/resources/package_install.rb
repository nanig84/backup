resource_name :package_install
property :package, String, required: true
property :version, String, required: false

def whyrun_supported?
  true
end

action :install do
  install_package
end

action :upgrade do
  install_package
end

action :remove do
  remove_package
end

def install_package
  require 'rinruby'
  if version.nil?
    R.eval "install.packages('#{package}')"
  else
    R.eval "install.packages('http://apsrs6756.uhc.com/R/src/contrib/#{package}_#{version}.tar.gz', repos=NULL, type='source', dependencies= 'TRUE')"
  end
end

def remove_package
  require 'rinruby'
  R.eval "remove.packages('#{package}')", false
end
