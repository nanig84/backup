USERDIR=/users
WRKDIR=/home/$USER/workdir

if [ $USER != 'root' ]; then
        # confirm users exists
        if [ ! -d $USERDIR/$USER ]; then
                mkdir $USERDIR/$USER
                chmod 700 $USERDIR/$USER
        fi
        STATUS=$?
        if [ $STATUS -ne 0 ]; then
                echo 'Failed to create user folder in /users, make sure your part of group - adatsciu, contact DSW Administrator'
                echo ''
        fi

        # confirm workfir exists
        if [ ! -h $HOME/workdir ]; then
                ln -s $USERDIR/$USER $WRKDIR
        fi
        STATUS=$?
        if [ $STATUS -ne 0 ]; then
                echo 'Failed to create workdir folder, contact DSW Administrator'
                echo ''
        fi
fi
