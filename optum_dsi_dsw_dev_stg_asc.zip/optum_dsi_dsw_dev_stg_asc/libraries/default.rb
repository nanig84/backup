def r_package_installed?(package)
  require 'rinruby'
  R.echo(enable: false)
  R.eval 'packages = installed.packages()[,1]'
  packages = R.pull 'packages'
  packages.include?(package)
end

def packages_list
  require 'rinruby'
  R.echo(enable: false)
  R.eval 'packages = installed.packages()[,1]'
  packages = R.pull 'packages'
  packages
end

def check_package_status
  packages = packages_list

  installed_pkgs = []
  not_installed_pkgs = []

  node['package_names'].keys.each do |pkg|
    if packages.include?(pkg)
      installed_pkgs << pkg
    else
      not_installed_pkgs << pkg
    end
  end

  file_fail = File.new('/tmp/uninstalled_pkgs.txt', 'w+')
  not_installed_pkgs.size.times do |val|
    file_fail.write("#{val + 1}:#{not_installed_pkgs[val]}\n")
  end
  file_fail.close

  file_pass = File.new('/tmp/installed_pkgs.txt', 'w+')
  installed_pkgs.size.times do |val|
    file_pass.write("#{val + 1}:#{installed_pkgs[val]}\n")
  end
  file_pass.close

  if not_installed_pkgs.empty?
    puts "\n"
    puts '##############################'
    puts 'All the packages are installed'
    puts '##############################'
  else
    raise "#{not_installed_pkgs} are not installed"
  end
end
