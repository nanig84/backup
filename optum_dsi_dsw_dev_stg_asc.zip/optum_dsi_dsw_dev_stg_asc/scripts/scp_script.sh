#!/bin/bash

dir="/var/www/html/mapr_repo"
file_looking_for=".rpm"
Email_ID="goutham.guduguntla@optum.com"


# Create Status of Folder
ls /tmp/watchfile
if [ $? -ne 0 ] ; then
    ls -l $dir | grep $file_looking_for > /tmp/"$file_looking_for"_watchfile


# Copy files from folder to /var/www/html/mapr_repo
cp /mapr/datalake/uhg_admin/install/client/v521/* $dir/
cp /mapr/datalake/uhg_admin/install/ecosystem/v521/* $dir/


ls -l $dir | grep $file_looking_for > /tmp/"$file_looking_for"_watchfile2
diff -q /tmp/"$file_looking_for"_watchfile /tmp/"$file_looking_for"_watchfile2 > /tmp/"$file_looking_for"_change_list
if [ $? -ne 0 ] ; then
   # sendmail to team
   mail -s "Files List has changed for $file_looking_for"  $Email_ID < /tmp/"$file_looking_for"_change_list
   ### Trigger cookbook build process
   exit ;
fi
cp /tmp/"$file_looking_for"_watchfile2 /tmp/"$file_looking_for"_watchfile
