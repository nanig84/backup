hname = node['hostname']
# hzone = node[hname.to_s]['zone']
# henv  = node[hname.to_s]['env']

directory '/app/zeppelin' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/app/packages/zeppelin-0.7.2-bin-all.tgz' do
  source "#{node['repo_server']}/softwares/zeppelin-0.7.2-bin-all.tgz"
  action :create
end

bash 'extract_module' do
  cwd '/app/packages'
  code <<-EOH
    tar -xzvf /app/packages/zeppelin-0.7.2-bin-all.tgz -C /app/zeppelin
    mv /app/zeppelin/zeppelin-0.7.2-bin-all /app/zeppelin/zeppelin-0.7.2
    chown -R root:root /app/zeppelin/zeppelin-0.7.2
    EOH
  not_if { ::File.exist?('/app/zeppelin/zeppelin-0.7.2') }
end
# execute "tar -xzvf /packages/zeppelin-0.7.2-bin-all.tgz  -C /app/zeppelin" do
#   cwd '/app/zeppelin/'
#   not_if { File.exist?("/app/zeppelin/zeppelin-0.7.2") }
# end
#
# execute "mv /app/zeppelin/zeppelin-0.7.2-bin-all /app/zeppelin/zeppelin-0.7.2" do
#   cwd '/app/zeppelin/'
#   not_if { File.exist?("/app/zeppelin/zeppelin-0.7.2") }
#  end

if node['platform_version'] >= '7'
  cookbook_file '/etc/systemd/system/zeppelin.service' do
    source 'zeppelin/zeppelin.service'
    mode '0755'
    action :create
  end
else
  cookbook_file '/etc/init.d/zeppelin' do
    source 'zeppelin/zeppelinprod'
    mode '0755'
    action :create
  end
end

cookbook_file '/app/zeppelin/zeppelin-0.7.2/conf/interpreter.json' do
  source "zeppelin/interpreter-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.json"
  mode '0750'
  action :create
end

cookbook_file '/app/zeppelin/zeppelin-0.7.2/conf/shiro.ini' do
  source 'zeppelin/shiro.ini'
  mode '0750'
  action :create
end

cookbook_file '/app/zeppelin/zeppelin-0.7.2/conf/zeppelin-site.xml' do
  source "zeppelin/zeppelin-site-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.xml"
  mode '0750'
  action :create
end

directory '/app/zeppelin/zeppelin-0.7.2/logs' do
  owner 'root'
  group 'root'
  mode '0775'
  action :create
end

service 'zeppelin' do
  action %i(enable start)
end
