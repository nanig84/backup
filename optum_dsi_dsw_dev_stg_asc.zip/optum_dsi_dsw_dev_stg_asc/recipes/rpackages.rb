cookbook_file '/opt/r_packages_300.json' do
  source 'r_packages_300.json'
end

if node['platform_version'] >= '7'
  execute 'epel rpm installation' do
    command 'sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm'
    ignore_failure true
  end

  ['tk.x86_64', 'nlopt', 'nlopt-devel'].each do |pkg|
    package pkg do
      action :install
    end
  end

else
  execute 'epel rpm installation' do
    command 'sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-6.noarch.rpm'
  end
end

cron 'r-packages-install' do
  minute '0'
  hour '*/23'
  mailto 'goutham.guduguntla@optum.com'
  command 'chef-client -o recipe[optum_mapr::r-packages-install] -j /opt/r_packages_300.json'
  action :create
end
