#
# Cookbook Name:: optum_mapr/
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
# hname = "#{node['hostname']}"
# hzone = "#{node[hname]}#{node['zone']}"
# henv  = "#{node[hname]}#{node['env']}"
# #hpkgmapr = node[hzone][henv]['mapr']
hname = node['hostname']
hzone = node[hname.to_s]['zone']
henv  = node[hname.to_s]['env']
# hpkgmapr = node[hzone.to_s][henv.to_s]['mapr']
#
cookbook_file '/etc/profile.d/hadoop_env.sh' do
  source 'mapr/hadoop.env'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

# ["#{node[hzone]}#{node[henv]}#{node['mapr']}"].each do |p|
node[hzone.to_s][henv.to_s]['mapr'].each do |p|
  yum_package p do
    ignore_failure true
  end
end

link '/opt/mapr/hbase/hbase' do
  to '/opt/mapr/hbase/hbase-1.1.8'
end

link '/opt/mapr/hadoop/hadoop' do
  to '/opt/mapr/hadoop/hadoop-2.7.0'
end

link '/opt/mapr/hive/hive' do
  to '/opt/mapr/hive/hive-2.1'
end

link '/opt/mapr/spark/spark' do
  to '/opt/mapr/spark/spark-2.1.0'
end

directory '/opt/mapr/tmp' do
  owner 'root'
  group 'root'
  mode '0755'
  recursive true
  action :create
end

directory '/opt/mapr/tmp/aaldbpdv' do
  owner 'root'
  group 'root'
  mode '0777'
  action :create
end

directory '/opt/mapr/tmp/aalbdplt' do
  owner 'root'
  group 'root'
  mode '0777'
  action :create
end

directory '/opt/mapr/tmp/opiuaprd' do
  owner 'root'
  group 'root'
  mode '0777'
  action :create
end

directory '/opt/mapr/tmp/opibdprd' do
  owner 'root'
  group 'root'
  mode '0777'
  action :create
end

directory '/opt/mapr/tickets' do
  owner 'root'
  group 'root'
  mode '0777'
  action :create
end

directory '/opt/mapr/java' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/opt/mapr/java/jdk-8u101-linux-x64.tar.gz' do
  source "#{node['repo_server']}/softwares/jdk-8u101-linux-x64.tar.gz"
  action :create
end

bash 'extract_module' do
  cwd '/opt/mapr/java'
  code <<-EOH
    tar -xzf jdk-8u101-linux-x64.tar.gz
    EOH
  not_if { ::File.exist?('/opt/mapr/java/jdk1.8.0_101') }
end

remote_file '/opt/mapr/conf/ssl_truststore' do
  source "#{node['repo_server']}/mapr/#{node[hzone.to_s][henv.to_s]['ssl_truststore']}"
  action :create
end

link '/opt/mapr/conf/ssl-client.xml' do
  to '/opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop/ssl-client.xml'
end

link '/opt/mapr/conf/ssl-server.xml' do
  to '/opt/mapr/hadoop/hadoop-2.7.0/etc/hadoop/ssl-server.xml'
end

cookbook_file '/opt/mapr/conf/dbclient.conf' do
  source 'mapr/dbclient.conf'
  mode '0755'
  action :create
end

link '/opt/mapr/sqoop/sqoop' do
  to '/opt/mapr/sqoop/sqoop-1.4.6'
end

remote_file '/opt/mapr/spark/spark-2.1.0/jars/hadoop-yarn-server-web-proxy-2.6.0.jar' do
  source "#{node['repo_server']}/softwares/hadoop-yarn-server-web-proxy-2.6.0.jar"
  action :create
end

remote_file '/opt/mapr/spark/spark-2.1.0/examples/jars/spark-examples_2.11-2.1.0-mapr-1703.jar' do
  source "#{node['repo_server']}/softwares/spark-examples_2.11-2.1.0-mapr-1703.jar"
  action :create
end

cookbook_file '/opt/mapr/sqoop/sqoop/conf/sqoop-site.xml' do
  source 'mapr/sqoop-site.xml'
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/conf/mapr-clusters.conf' do
  source "mapr/mapr-clusters-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.conf"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/hadoop/hadoop/etc/hadoop/mapred-site.xml' do
  source "mapr/mapred-site-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/hadoop/hadoop/etc/hadoop/yarn-site.xml' do
  source "mapr/yarn-site-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/spark/spark/conf/hive-site.xml' do
  source "hive/hive-site-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/hbase/hbase/hbase-site.xml' do
  source "hbase/hbase-site-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/hive/hive/conf/hive-site.xml' do
  source "hive/hive-sitexml-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.xml"
  mode '0755'
  action :create
end

cookbook_file '/opt/mapr/spark/spark/conf/spark-defaults.conf' do
  source "spark/spark-defaults-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}.conf"
  mode '0755'
  action :create
end

cookbook_file '/etc/hosts' do
  source "os/host-#{node[hname.to_s]['zone']}#{node[hname.to_s]['env']}"
  mode '0755'
  action :create
end

# MAPR TICKET PAM
remote_file '/opt/mapr/lib/libmapr_pam.so' do
  source "#{node['repo_server']}/softwares/mapr/libmapr_pam.so"
  action :create
end

directory '/opt/mapr/tickets' do
  owner 'root'
  group 'root'
  mode '0777'
  action :create
end

cookbook_file '/etc/pam.d/system-auth-local' do
  source 'os/PAM-system-auth-local'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

cookbook_file '/etc/pam.d/password-auth-ac' do
  source 'os/PAM-password-auth-ac'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end
