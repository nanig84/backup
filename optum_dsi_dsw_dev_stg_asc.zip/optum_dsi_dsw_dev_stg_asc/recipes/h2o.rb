directory '/app/packages' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
  recursive true
end

package 'unzip'

# Installing h20
directory '/app/h2o' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/app/packages/h2o-3.14.0.1-mapr5.2.zip' do
  source "#{node['repo_server']}/softwares/h2o-3.14.0.1-mapr5.2.zip"
  action :create
end

execute 'unzip /app/packages/h2o-3.14.0.1-mapr5.2.zip -d /app/h2o/' do
  not_if { File.exist?('/app/h2o/h2o-3.14.0.1-mapr5.2') }
end
# make sure h20 packages insync, python vs server

# Installing Sparking Water
directory '/app/sparkling-water' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/app/packages/sparkling-water-2.1.13.zip' do
  source "#{node['repo_server']}/softwares/sparkling-water-2.1.13.zip"
  action :create
end

execute 'unzip /app/packages/sparkling-water-2.1.13.zip -d /app/sparkling-water/' do
  not_if { File.exist?('/app/sparkling-water/sparkling-water-2.1.13') }
end
