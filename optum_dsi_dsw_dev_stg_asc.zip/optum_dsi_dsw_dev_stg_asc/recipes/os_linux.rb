
#Resources for installing Linux OV
remote_file '/app/packages/linux-OV-install.tar' do
  source "#{node['repo_server']}/softwares/linux-OV-install.tar"
  action :create
end

bash 'extract_module linux-OV' do
  cwd '/app/packages'
  code <<-EOH
    tar -xf /app/packages/linux-OV-install.tar
    EOH
  not_if { ::Dir.exist?('/app/packages/linux-OV') }
end
bash 'install_module linux-OV' do
  cwd '/app/packages/linux-OV'
  code <<-EOH
    ./install.sh
    EOH
  not_if { ::File.exist?('/opt/OV') }
end

if node['platform_version'] >= '7'
  #Rsources for installing Bare OS
  remote_file '/etc/yum.repos.d/bareos.repo' do
    source 'http://download.bareos.org/bareos/release/17.2/RHEL_7/bareos.repo'
    action :create
    only_if { Mixlib::ShellOut.new('rpm -qa | grep bareos').run_command.stdout.empty? }
  end

  yum_package 'bareos-fd' do
    flush_cache [:before]
  end

  cookbook_file '/etc/bareos/bareos-fd.d/director/bareos-dir.conf' do
    source 'os/bareos-dir.conf'
    mode '0640'
    owner 'root'
    group 'bareos'
    action :create
  end

  service 'bareos-fd' do
    action %i(enable start)
  end

  file '/etc/yum.repos.d/bareos.repo' do
    action :delete
    only_if { ::File.exist?('/etc/yum.repos.d/bareos.repo') }
  end

end

#resources for installing docker-engine
remote_file '/app/packages/docker-engine-1.7.1-1.el6.x86_64.rpm' do
  source "#{node['repo_server']}/softwares/docker-engine-1.7.1-1.el6.x86_64.rpm"
  # source "#{node['repo_server']}/softwares/nz/nz.tar"
  action :create
end

yum_package 'docker-engine' do
  source '/app/packages/docker-engine-1.7.1-1.el6.x86_64.rpm'
  flush_cache [:before]
end

#resources for installing clush
if node['platform_version'] >= '7'
  remote_file '/app/packages/clustershell-1.7.3-1.el7.noarch.rpm' do
    source "#{node['repo_server']}/softwares/clustershell-1.7.3-1.el7.noarch.rpm"
    # source "#{node['repo_server']}/softwares/nz/nz.tar"
    action :create
  end

  yum_package 'clush' do
    source '/app/packages/clustershell-1.7.3-1.el7.noarch.rpm'
    flush_cache [:before]
  end
end

#Installing julia
remote_file '/app/packages/julia-0.6.1-linux-x86_64.tar.gz' do
  source "#{node['repo_server']}/softwares/julia-0.6.1-linux-x86_64.tar.gz"
  action :create
end

directory '/app/julia' do
  action :create
end

bash 'extract_module' do
  cwd '/app/packages'
  code <<-EOH
    tar -xzvf /app/packages/julia-0.6.1-linux-x86_64.tar.gz -C /app/julia
    EOH
  not_if { ::File.exist?('/app/julia/julia-0d7248e2ff/bin/julia') }
end

link '/usr/local/bin/julia' do
  to '/app/julia/julia-0d7248e2ff/bin/julia'
end

cookbook_file '/etc/sudoers.d/all_%adatscia' do
  source 'os/sudoers_adatscia'
  owner 'root'
  group 'root'
  mode '0440'
  action :create
end

#Portal Shortcuts
directory '/app/portal' do
  owner 'root'
  group 'adatsciu'
  mode '0755'
  recursive true
  action :create
end

#link '/usr/lib64/microsoft-r/3.3/lib64/R/library/h2o/java/h2o.jar' do
#  to '/app/portal/h2o'
#end

link '/app/anaconda3/bin/spyder' do
  to '/app/portal/spyder'
end

link '/app/pycharm/pycharm-community-2017.2.3/bin/pycharm' do
  to '/app/portal/pycharm'
end

link '/app/weka/weka-3-8-1/weka.jar' do
  to '/app/portal/weka'
end

cookbook_file '/app/portal/sparklingwater' do
  source 'scripts/sparklingwater'
  owner 'root'
  group 'adatsciu'
  mode '0750'
  action :create
end

#SSH.Keys.add
if node['platform_version'] >= '6'
  names = Dir.entries('/home')

  names.each do |usernames|
    next unless usernames != '.' && usernames != '..'
    cmd = Mixlib::ShellOut.new("id #{usernames} > /dev/null")
    cmd.run_command
    next if cmd.error?
    linux_regex_key = 'ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAQEApvXU90GJqPFw5NRhdgUv7PRFfnwju2uMw0OMMHrwNKTfuIUP9GtCfaZ4CP7gAFYwdf6oOndBXt1P732.k.gCDZuGORxRqMxL1qVIUX7jnEvmTCeNR43baFwFAlyrhLmZVOfQmy.KTTWLNHcVKjpAPGfWGPXRf.MXsQ9apB6ifQfhJ.QEbmr.tWcHdNciyg.K01SMrr4TN9swducHq.3Egf9.R9Kw..GhHwa4VhNeoaUQelZ0N84E.ysRG0ultYRtp4XMS4uvTZpE2rGw8EdAF5IAgzzxb3ccT9o2SsZfRPRvD.GapNbqT.jWsd2qV.9yLo0F1m4bGteaOqrMH88C5w.. dswportal.utd.rsa'

    linux_user_key = 'ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAQEApvXU90GJqPFw5NRhdgUv7PRFfnwju2uMw0OMMHrwNKTfuIUP9GtCfaZ4CP7gAFYwdf6oOndBXt1P732+k/gCDZuGORxRqMxL1qVIUX7jnEvmTCeNR43baFwFAlyrhLmZVOfQmy+KTTWLNHcVKjpAPGfWGPXRf+MXsQ9apB6ifQfhJ/QEbmr+tWcHdNciyg/K01SMrr4TN9swducHq/3Egf9+R9Kw++GhHwa4VhNeoaUQelZ0N84E/ysRG0ultYRtp4XMS4uvTZpE2rGw8EdAF5IAgzzxb3ccT9o2SsZfRPRvD+GapNbqT+jWsd2qV+9yLo0F1m4bGteaOqrMH88C5w== dswportal_utd_rsa'

    directory "/home/#{usernames}/.ssh" do
      user usernames
      mode '0700'
      recursive true
      action :create
    end

    file "/home/#{usernames}/.ssh/authorized_keys" do
      mode '0654'
      owner usernames
    end

    ruby_block "add entry to #{usernames} authorized keys file" do
      block do
        file = Chef::Util::FileEdit.new("/home/#{usernames}/.ssh/authorized_keys")
        file.insert_line_if_no_match(/(#{linux_regex_key})/, linux_user_key)
        file.write_file
      end
      only_if { Mixlib::ShellOut.new("grep '#{linux_regex_key}' \"/home/#{usernames}/.ssh/authorized_keys\"").run_command.stdout.empty? }
    end
  end
end
