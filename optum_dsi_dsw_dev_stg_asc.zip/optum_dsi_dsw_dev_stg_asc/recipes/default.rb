
#
# Cookbook Name:: optum_mapr/
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
# installing default required pacakge
# hname = "#{node['hostname']}"
# hzone = "#{node['zone']}#{node[hname]}"
# henv  = "#{node[hname]}#{node['env']}"
# hpkgmapr = "#{node[hzone]}#{node[henv]}#{node['mapr']}"
# node.normal['pkg_anaconda'] = "#{node[hzone]}#{node[henv]}#{node['anaconda']}"
# node.normal['pkg_zeppelin'] = "#{node[hzone]}#{node[henv]}#{node['zeppelin']}"
# node.normal['pkg_weka'] = "#{node[hzone]}#{node[henv]}#{node['weka']}"
# node.normal['pkg_openrefine'] = "#{node[hzone]}#{node[henv]}#{node['openrefine']}"
hname = node['hostname']
hzone = node[hname.to_s]['zone']
henv  = node[hname.to_s]['env']
# hpkgmapr = node[hzone.to_s][henv.to_s]['mapr']
node.normal['pkg_anaconda'] = node[hzone.to_s][henv.to_s]['anaconda']
node.normal['pkg_zeppelin'] = node[hzone.to_s][henv.to_s]['zeppelin']
node.normal['pkg_weka'] = node[hzone.to_s][henv.to_s]['weka']
node.normal['pkg_openrefine'] = node[hzone.to_s][henv.to_s]['openrefine']

node['pkg_name'].each do |pkg|
  yum_package pkg.to_s do
    flush_cache [:before]
  end
end

directory '/app/packages' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
  recursive true
end

directory '/etc/monitor' do
  action :create
end

directory '/users' do
  mode '0777'
  action :create
end

directory '/mapr' do
  action :create
end

directory '/hasassel' do
  action :create
end
# yum_repository 'optum_dsi' do
#   description 'DSI Repo'
#   baseurl 'http://apsrs6756.uhc.com/'
#   gpgcheck false
#   action :create
# end

template '/etc/yum.repos.d/optum_dsi.repo' do
  source 'optum_dsi_repo.erb'
  action :create
end

cookbook_file '/tmp/testfile' do
  source 'testfile'
end

include_recipe 'optum_dsi_dsw_dev_stg_asc::mapr'
include_recipe 'optum_dsi_dsw_dev_stg_asc::r'
include_recipe 'optum_dsi_dsw_dev_stg_asc::rstudio'
include_recipe 'optum_dsi_dsw_dev_stg_asc::anaconda'
include_recipe 'optum_dsi_dsw_dev_stg_asc::drivers'
include_recipe 'optum_dsi_dsw_dev_stg_asc::zeppelin'
include_recipe 'optum_dsi_dsw_dev_stg_asc::weka'
include_recipe 'optum_dsi_dsw_dev_stg_asc::h2o'
include_recipe 'optum_dsi_dsw_dev_stg_asc::openrefine'
include_recipe 'optum_dsi_dsw_dev_stg_asc::os_linux'
include_recipe 'optum_dsi_dsw_dev_stg_asc::rpackages'
