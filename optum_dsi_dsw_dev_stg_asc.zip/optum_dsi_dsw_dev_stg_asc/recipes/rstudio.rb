if node['platform_version'] < '7'
  remote_file '/app/packages/rstudio-0.98.1103-x86_64.rpm' do
    source "#{node['repo_server']}/softwares/extra_repo/rstudio-0.98.1103-x86_64.rpm"
    action :create
  end
  package 'rstudio-0.98' do
    source '/app/packages/rstudio-0.98.1103-x86_64.rpm'
    action :install
  end
else
  yum_package 'rstudio.x86_64' do
    # ignore_failure true
  end
end

# 'move rstudio to /app/R'
execute 'mv /usr/lib/rstudio /app/R/' do
  not_if { File.exist?('/app/R/rstudio') }
end

link '/usr/lib/rstudio' do
  to '/app/R/rstudio'
end

yum_package 'rstudio-server.x86_64' do
  # ignore_failure true
end

# 'move rstudio-server to /app/R' do
execute 'mv /usr/lib/rstudio-server /app/R/' do
  not_if { File.exist?('/app/R/rstudio-server') }
end

link '/usr/lib/rstudio-server' do
  to '/app/R/rstudio-server'
end

link '/usr/bin/rstudio' do
  to '/usr/lib/rstudio/bin/rstudio'
end

bash 'Copy login pam.d to rstudio' do
  user 'root'
  code <<-EOH
    cp /etc/pam.d/login /etc/pam.d/rstudio
  EOH
end

# add the below line /etc/rstudio/rserver.conf
# rsession-ld-library-path=/app/drivers/nz/lib64:/usr/lib/oracle/12.2/client64/lib:/opt/mapr/java/jdk1.8.0_101
bash 'adding rsession-id to rserver.conf' do
  user 'root'
  code <<-EOH
    grep "rsession-ld-library-path=/app/drivers/nz/lib64:/usr/lib/oracle/12.2/client64/lib:/opt/mapr/java/jdk1.8.0_101"  /etc/rstudio/rserver.conf | grep -v grep
    if [ $? -ne 0 ]
    then
        echo "rsession-ld-library-path=/app/drivers/nz/lib64:/usr/lib/oracle/12.2/client64/lib:/opt/mapr/java/jdk1.8.0_101" >> /etc/rstudio/rserver.conf
        echo "rsession-which-r=/usr/bin/R_3.3.3" >> /etc/rstudio/rserver.conf
    fi
  EOH
end

cookbook_file '/etc/rstudio/profiles' do
  source 'R/profiles'
  action :create
end

if node['platform_version'] < '7'
  cookbook_file '/etc/init.d/rstudio' do
    source 'R/rstudioprod'
    mode '0755'
    action :create
  end
  service 'rstudio' do
    action %i(enable start)
  end
end
