directory '/app/openrefine' do
  action :create
end

remote_file '/app/packages/openrefine-linux-2.7.tar.gz' do
  source "#{node['repo_server']}/softwares/openrefine-linux-2.7.tar.gz"
  action :create
end

execute 'tar -xzf /app/packages/openrefine-linux-2.7.tar.gz -C /app/openrefine' do
  not_if { File.exist?('/app/openrefine/openrefine-2.7') }
end

cookbook_file '/app/openrefine/openrefine-2.7/openrefine_start.sh' do
  source 'openrefine/openrefine_start.sh'
  mode '0755'
  action :create
end

if node['platform_version'] >= '7'
  cookbook_file '/etc/systemd/system/openrefine.service' do
    source 'openrefine/openrefine.service'
    mode '0755'
    action :create
  end
else
  cookbook_file '/etc/init.d/openrefine' do
    source 'openrefine/openrefineprod'
    mode '0755'
    action :create
  end
end

service 'openrefine' do
  action %i(enable start)
end
