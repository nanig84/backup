remote_file '/app/packages/nz.tar' do
  source "#{node['repo_server']}/softwares/nz/nz.tar"
  # source "#{node['repo_server']}/softwares/nz/nz.tar"
  action :create
end

bash 'extract_module' do
  cwd '/app'
  code <<-EOH
    mkdir -p  /app/drivers/
    tar xf /app/packages/nz.tar -C /app/drivers/
    EOH
  not_if { ::File.exist?('/app/drivers/nz') }
end

link '/nz' do
  to '/app/drivers/nz'
end

%w( oracle-instantclient12.2-basic oracle-instantclient12.2-devel
    oracle-instantclient12.2-odbc ).each do |oradriver|
  yum_package oradriver.to_s do
  end
end

remote_file '/usr/lib/oracle/12.2/client64/lib/ojdbc7.jar' do
  source "#{node['repo_server']}/softwares/ojdbc7.jar"
  action :create
end

directory '/app/drivers/Teradata' do
  action :create
end

remote_file '/app/drivers/Teradata/terajdbc4.jar' do
  source "#{node['repo_server']}/softwares/terajdbc4.jar"
  action :create
end

remote_file '/app/packages/nifi-1.3.0-bin.tar.gz' do
  source "#{node['repo_server']}/softwares/nifi-1.3.0-bin.tar.gz"
  # source "#{node['repo_server']}/softwares/nz/nz.tar"
  action :create
end

bash 'extract_module nifi' do
  cwd '/app'
  code <<-EOH
    mkdir -p  /app/nifi/
    tar -xzf /app/packages/nifi-1.3.0-bin.tar.gz -C /app/nifi/
    EOH
  not_if { ::File.exist?('/app/nifi/nifi-1.3.0') }
end

directory '/app/drivers/sqlsvr' do
  action :create
end

remote_file '/app/drivers/sqlsvr/sqljdbc42.jar' do
  source "#{node['repo_server']}/softwares/dbjars/sqljdbc42.jar"
  action :create
end

remote_file '/app/drivers/sqlsvr/sqljdbc4.jar' do
  source "#{node['repo_server']}/softwares/dbjars/sqljdbc4.jar"
  action :create
end

remote_file '/app/drivers/sqlsvr/jtds-1.3.1.jar' do
  source "#{node['repo_server']}/softwares/dbjars/jtds-1.3.1.jar"
  action :create
end

directory '/etc/skel' do
  action :create
end

cookbook_file '/etc/skel/.bshrc' do
  source 'os/skel.bashrc'
  action :create
end

cookbook_file '/etc/skel/.bash_profile' do
  source 'os/skel.bash_profile'
  action :create
end

cookbook_file '/etc/skel/.kshrc' do
  source 'os/skel.kshrc'
  action :create
end

cookbook_file '/etc/skel/.zshrc' do
  source 'os/skel.zshrc'
  action :create
end

cookbook_file '/etc/monitor/ProcessMonitor.ksh' do
  source 'scripts/ProcessMonitor.ksh'
  mode '0755'
  action :create
end

cookbook_file '/etc/monitor/default.conf' do
  source 'scripts/monitordefault.conf'
  mode '0755'
  action :create
end

cookbook_file '/etc/monitor/processWebMonitor.py' do
  source 'scripts/processWebMonitor.py'
  mode '0755'
  action :create
end

cookbook_file '/etc/profile.d/workdir.sh' do
  source 'os/workdir.sh'
  mode '0755'
  action :create
end

cookbook_file '/etc/odbcinst.ini' do
  source 'os/odbcinst.ini'
  mode '0755'
  action :create
end

# add repo for mssql RHEL 7
if node['platform_version'] >= '7'
  remote_file '/etc/yum.repos.d/mssql-release.repo' do
    source 'https://packages.microsoft.com/config/rhel/7/prod.repo'
    action :create
    only_if { Mixlib::ShellOut.new('rpm -qa | grep msodbcsql').run_command.stdout.empty? }
  end

  ENV['ACCEPT_EULA'] = 'Y'

  # yum_package 'unixODBC-utf16.x86_64' do
  #   flush_cache [:before]
  # end
  #
  # yum_package 'unixODBC-utf16-devel.x86_64' do
  #   flush_cache [:before]
  # end

  yum_package 'mssql-tools.x86_64' do
    flush_cache [:before]
  end

  file '/etc/yum.repos.d/mssql-release.repo' do
    action :delete
    only_if { ::File.exist?('/etc/yum.repos.d/mssql-release.repo') }
  end
end

# add repo for mssql RHEL 6
if node['platform_version'] <= '7'
  remote_file '/etc/yum.repos.d/mssql-release.repo' do
    source 'https://packages.microsoft.com/config/rhel/6/prod.repo'
    action :create
    only_if { Mixlib::ShellOut.new('rpm -qa | grep msodbcsql').run_command.stdout.empty? }
  end

  ENV['ACCEPT_EULA'] = 'Y'

  # yum_package 'unixODBC.x86_64' do
  #   flush_cache [:before]
  # end

  yum_package 'unixODBC-devel.x86_64' do
    flush_cache [:before]
  end

  yum_package 'mssql-tools.x86_64' do
    flush_cache [:before]
  end

  link '/usr/bin/sqlcmd' do
    to '/opt/mssql-tools/bin/sqlcmd-13.0.1.0'
  end

  link '/usr/bin/bcp' do
    to '/opt/mssql-tools/bin/bcp-13.0.1.0'
  end

  file '/etc/yum.repos.d/mssql-release.repo' do
    action :delete
    only_if { ::File.exist?('/etc/yum.repos.d/mssql-release.repo') }
  end
end
