name 'optum_dsi_dsw_dev_stg_asc' # ~FCO78
maintainer 'Goutham Guduguntla'
maintainer_email 'goutham.guduguntla@optum.com'
license 'All Rights Reserved' # ~FCO78
description 'Installs/Configures optum dsi tools'
long_description 'Installs/Configures optum_mapr'
version '0.0.10'

# The `issues_url` points to the location where issues for this cookbook are
# tracked.  A `View Issues` link will be displayed on this cookbook's page when
# uploaded to a Supermarket.
#
# issues_url 'https://github.com/<insert_org_here>/optum_mapr/issues'
# if respond_to?(:issues_url)

# The `source_url` points to the development reposiory for this cookbook.  A
# `View Source` link will be displayed on this cookbook's page when uploaded to
# a Supermarket.
#
# source_url 'https://github.com/<insert_org_here>/optum_mapr' if respond_to?
# (:source_url)
chef_version '>=12.0' if respond_to?(:chef_version)
supports 'redhat'
issues_url 'https://github.optum.com/DSI/optum_dsi_dsw_dev_stg_asc.git' if respond_to?(:issues_url)
source_url 'https://github.optum.com/DSI/optum_dsi_dsw_dev_stg_asc.git' if respond_to?(:source_url)
