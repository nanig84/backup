# host adding new #

case node['hostname']
when 'apsrs6775'
  default['apsrs6775']['zone'] = 'unh'
  default['apsrs6775']['env'] = 'dev'
when 'apsrs6756'
  default['apsrs6756']['zone'] = 'unh'
  default['apsrs6756']['env'] = 'test'
when 'apsrd9425'
  default['apsrd9425']['zone'] = 'com'
  default['apsrd9425']['env'] = 'dev'
when 'apsrd9601'
  default['apsrd9601']['zone'] = 'unh'
  default['apsrd9601']['env'] = 'dev'
when 'apsrp04093'
  default['apsrp04093']['zone'] = 'unh'
  default['apsrp04093']['env'] = 'prod'
when 'apsrs7131'
  default['apsrs7131']['zone'] = 'unh'
  default['apsrs7131']['env'] = 'test'
when 'apsrp04767'
  default['apsrp04767']['zone'] = 'unh'
  default['apsrp04767']['env'] = 'stg'
when 'apsrp04768'
  default['apsrp04768']['zone'] = 'unh'
  default['apsrp04768']['env'] = 'stg'
when 'apsrt4653'
  default['apsrt4653']['zone'] = 'unh'
  default['apsrt4653']['env'] = 'test'
when 'apsrs7624'
  default['apsrs7624']['zone'] = 'unh'
  default['apsrs7624']['env'] = 'stg'
when 'apsrp01876'
  default['apsrp01876']['zone'] = 'com'
  default['apsrp01876']['env'] = 'prod'
else
  host = node['hostname']
  default[host]['zone'] = 'unh'
  default[host]['env'] = 'test'
end

default['repo_server'] = 'http://apsrs6756.uhc.com/'
# default['nodejs_url'] = 'https://rpm.nodesource.com/setup_6.x'
default['pkg_name'] = %w( pcre pcre-devel xz xz-devel bzip2-devel libicu-devel
                          gcc-gfortran.x86_64
                          zlib.x86_64
                          libtool
                          readline-devel
                          python-devel.x86_64
                          libxml2-devel
                          openssl-devel.x86_64
                          libcurl-devel
                          gcc-c++
                          make
                          gcc
                          firefox
                          git
                          zlib.x86_64
                          zlib-devel.x86_64 nfs-utils
                          java-1.8.0-openjdk-devel
                          nss
                          unzip)
