default['com']['dev']['microsfotr'] = 'microsoftr-x.x.x.tar.gz'
default['com']['dev']['zeppelin'] = 'zeppelin-0.7.2-bin-all.tgz'
default['com']['dev']['mapr'] = %w(mapr-client.x86_64 mapr-hbase.noarch
                                   mapr-hive.noarch mapr-hivemetastore.noarch
                                   mapr-hiveserver2.noarch mapr-spark.noarch
                                   mapr-sqoop.noarch)
default['com']['dev']['anaconda'] = 'Anaconda3-4.3.1-Linux-x86_64.sh'
default['com']['dev']['zeppelin'] = 'zeppelin-0.7.2-bin-all.tgz'
default['com']['dev']['ssl_truststore'] = 'ssl_truststore_prd'

default['com']['stg']['mapr'] = %w(mapr-client.x86_64 mapr-hbase.noarch)
# default['com']['Prodzone']['mapr'] = %w[mapr-spark.noarch]

default['com']['prod']['microsfotr'] = 'microsoftr-x.x.x.tar.gz'
default['com']['prod']['zeppelin'] = 'zeppelin-0.7.2-bin-all.tgz'
default['com']['prod']['mapr'] = %w(mapr-core.x86_64 mapr-core-internal.x86_64
                                    mapr-mapreduce1.x86_64 mapr-mapreduce2.x86_64
                                    mapr-hadoop-core.x86_64 mapr-hbase.noarch
                                    mapr-hive.noarch mapr-hivemetastore.noarch
                                    mapr-hiveserver2.noarch mapr-spark.noarch
                                    mapr-sqoop.noarch mapr-pig.noarch)
default['com']['prod']['anaconda'] = 'Anaconda3-4.3.1-Linux-x86_64.sh'
default['com']['prod']['zeppelin'] = 'zeppelin-0.7.2-bin-all.tgz'
default['com']['prod']['ssl_truststore'] = 'ssl_truststore_prd'
